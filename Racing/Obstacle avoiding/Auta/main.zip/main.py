import pygame, random, sys
 
pygame.init()
W, H = 400, 600
ekran = pygame.display.set_mode((W, H))
clock = pygame.time.Clock()
tlo = pygame.image.load("tło.jpg")
 
# Gracz
auto_gracza = pygame.image.load('auto.png')
truck = pygame.image.load('truck.png')
gracz = auto_gracza.get_rect()
gracz.center = (200, 500)
kolor_gracza = (0, 200, 0)
 
# Przeszkody
przeszkody = []
def dodaj_przeszkode():
    x = random.choice([80, 150, 240, 320])
    przeszkoda = truck.get_rect()
    przeszkoda.center = (x, -50)
    przeszkody.append(przeszkoda)
 
# Punkty
score = 0
 
# Główna pętla
dodaj_przeszkode()
while True:
    ekran.fill((255, 255, 255))
 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
 
    # Sterowanie
    klawisze = pygame.key.get_pressed()
    gracz.x += ((klawisze[pygame.K_RIGHT] and gracz.right < W-30) - (klawisze[pygame.K_LEFT] and gracz.left > 30)) * 5
 
    # Aktualizacja przeszkód
    for p in przeszkody[:]:
        p.y += 5 + score // 10
        if p.colliderect(gracz):
            przeszkody = []
            dodaj_przeszkode()
            score = 0
        if p.y > H:
            przeszkody.remove(p)
            score += 1
 
    if przeszkody[-1].y > 150:
        dodaj_przeszkode()
    
    # Dodaj tło
    ekran.blit(tlo, (0,0))

    # Rysowanie
    ekran.blit(auto_gracza, gracz)
    for p in przeszkody:
        ekran.blit(truck, p)
 
    # Wyświetlanie punktów
    font = pygame.font.SysFont("Calibri", 36)
    tekst = font.render(f"Punkty: {score}", True, (0, 0, 0), (200, 255, 200))
    ekran.blit(tekst, (10, 10))
 
    pygame.display.flip()
    clock.tick(60)